import Mercedes
from Honda import *

print("Mercedes models : ", Mercedes.Models())
print("Honda models : ",models())

