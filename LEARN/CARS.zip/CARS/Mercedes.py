def Models():
  s1 = "Benz"
  s2 = "Maybach"
  s3 = "GT63"

  Mer = (s1,s2,s3)
  return Mer
