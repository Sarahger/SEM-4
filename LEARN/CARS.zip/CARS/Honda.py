def models():
  s1 = "City"
  s2 = "Amaze"
  s3 = "Breeze"
  
  Hon = (s1,s2,s3)
  return Hon
